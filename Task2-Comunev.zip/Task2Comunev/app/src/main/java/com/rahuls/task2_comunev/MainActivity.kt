package com.rahuls.task2_comunev

import android.net.ConnectivityManager
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.google.gson.JsonSyntaxException
import org.json.JSONException
import java.util.*

class MainActivity : AppCompatActivity() {
    private val FETCHURL = "https://restcountries.eu/rest/v2/region/asia"
    lateinit var recipes: List<FullName>
    private lateinit var recyclerview: RecyclerView
    private lateinit var arrayList: ArrayList<FullName>
    private lateinit var adapter: MyNameAdapter
    private lateinit var pb: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pb = findViewById(R.id.pb)
        pb.visibility = View.GONE
        recyclerview = findViewById(R.id.recyclerview)
        arrayList = ArrayList<FullName>()
        adapter = MyNameAdapter(this, arrayList)
        val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(applicationContext)
        recyclerview.layoutManager = mLayoutManager
        recyclerview.itemAnimator = DefaultItemAnimator()
        recyclerview.isNestedScrollingEnabled = false
        recyclerview.adapter = adapter
        if (isNetworkAvailable()) {
            fetchfromServer()
        } else {
            fetchfromRoom()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
    }


    private fun fetchfromRoom() {
        val thread = Thread {
            val recipeList: List<Names>? =
                NamesRepository.getInstance(this@MainActivity)?.getAppDatabase()?.namesDao()
                    ?.getAll()
            arrayList.clear( )
            if (recipeList != null) {
                for (recipe in recipeList) {
                    val repo = FullName(
                        recipe.id,
                        recipe.tName,
                        recipe.fName,
                        recipe.lName,
                    )
                    arrayList.add(repo)
                }
            }
            // refreshing recycler view
            runOnUiThread { adapter.notifyDataSetChanged() }
        }
        thread.start()
    }

    private fun fetchfromServer() {
        pb.visibility = View.VISIBLE
        val request = JsonArrayRequest(FETCHURL,
            Response.Listener { response ->
                if (response == null) {
                    pb.visibility = View.GONE
                    Toast.makeText(
                        applicationContext,
                        "Couldn't fetch the menu! Please try again.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@Listener
                }
                try {
                    for (i in 0 until response.length()) {
                        // Get current json object
                        val result = response.getJSONObject(i)
                        val continent = FullName(0,"","","")

                        val persons = (result.getJSONArray("results"))

                        for (i in 0 until persons.length()) {
                            val item = persons.getJSONObject(i)

                            // Get the current student (json object) data
                            val name = (item.getJSONObject("name"))

                            // Your code here
                            continent.title = (name.getString("title"))
                            continent.first = (name.getString("first"))
                            continent.last = (name.getString("last"))
                        }

                        // Display the formatted json data in text view
                        arrayList.add(continent)
                    }
                } catch (e: JsonSyntaxException) {
                    e.printStackTrace()
                } catch (e: JSONException) {
                    e.printStackTrace()
                }


                // refreshing recycler view
                adapter.notifyDataSetChanged()
                pb.visibility = View.GONE
                saveTask()
            }, { error -> // error in getting json
                pb.visibility = View.GONE
                Log.e("TAG", "Error: " + error.message)
                Toast.makeText(applicationContext, "Error: " + error.message, Toast.LENGTH_SHORT)
                    .show()
            })
        val requestQueue = Volley.newRequestQueue(this)
        request.setShouldCache(false)
        requestQueue.add(request)
    }


    private fun saveTask() {
        class SaveTask : AsyncTask<Void?, Void?, Void?>() {

            override fun onPostExecute(avoid: Void?) {
                super.onPostExecute(avoid)
                Toast.makeText(applicationContext, "Saved", Toast.LENGTH_LONG).show()
            }

            override fun doInBackground(vararg params: Void?): Void? {
                recipes = arrayList

                //creating a task
                if (recipes == null) {
                    NamesRepository.getInstance(applicationContext)?.getAppDatabase()?.namesDao()
                        ?.insert(Names())
                    return null
                }
                for (i in recipes.indices) {
                    val recipe = Names()
                    recipe.tName = recipes.get(i).title
                    recipe.fName = recipes.get(i).first
                    recipe.lName = recipes.get(i).last
                    NamesRepository.getInstance(applicationContext)?.getAppDatabase()?.namesDao()
                        ?.insert(recipe)
                }
                return null
            }
        }

        val st = SaveTask()
        st.execute()
    }

    fun deleteAll(view: View?) {
        NamesRepository.getInstance(this@MainActivity)?.getAppDatabase()?.namesDao()?.deleteAll()
        fetchfromRoom()
    }

    fun refresh(view: View?) {
        fetchfromServer()
    }
}