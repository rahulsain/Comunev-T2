package com.rahuls.task2_comunev

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query

@Dao
interface NamesDao {
    // allowing the insert of the same word multiple times by passing a
    // conflict resolution strategy
    @Insert
    fun insert(country: Names)

    @Query("SELECT * FROM name_table")
    fun getAll(): List<Names>

    @Query("DELETE FROM name_table")
    fun deleteAll()
}