package com.rahuls.task2_comunev

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase

@Database(entities = [Names::class], version = 1,exportSchema = false)
abstract class NamesRoomDatabase : RoomDatabase() {
    abstract fun namesDao(): NamesDao?
}