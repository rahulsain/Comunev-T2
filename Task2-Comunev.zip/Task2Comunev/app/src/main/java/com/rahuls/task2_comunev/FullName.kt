package com.rahuls.task2_comunev

class FullName(var id: Int, var title: String, var first: String, var last: String) {

}